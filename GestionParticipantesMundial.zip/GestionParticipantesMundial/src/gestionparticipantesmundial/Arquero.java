/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package gestionparticipantesmundial;


import gestionparticipantesmundial.NivelExperiencia;

/**
 *
 * @author Mauro Rosales
 */
public class Arquero extends Futbolista implements Informable{
    private int cantAtajadasRealizadas;

    public Arquero(String nombre, String pais, NivelExperiencia nivelExperiencia, int numeroCamiseta, int cantPartidosDisputados, int cantAtajadasRealizadas) {
        super(nombre, pais, nivelExperiencia, numeroCamiseta, cantPartidosDisputados);
        super.validarInt(cantAtajadasRealizadas, "La cantAtajadasRealizadas no puede ser menor a cero.");
        this.cantAtajadasRealizadas = cantAtajadasRealizadas;
    }

    @Override
    public String toString() {
        return super.toString()+" " + "cantAtajadasRealizadas=" + cantAtajadasRealizadas + "]";
    }

    @Override
    public String generarInforme() {
        return "Informe del arquero "+getNombre()+": "+cantAtajadasRealizadas+" atajadas en "+getCantPartidosDisputados()+" partidos.";
    }


}
