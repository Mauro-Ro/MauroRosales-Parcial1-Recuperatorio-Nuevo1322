/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package gestionparticipantesmundial;


import gestionparticipantesmundial.NivelExperiencia;

/**
 *
 * @author Mauro Rosales
 */
public abstract class Futbolista extends Participante implements Entrenable{
    private int numeroCamiseta;
    private int cantPartidosDisputados;

    public Futbolista(String nombre, String pais, NivelExperiencia nivelExperiencia, int numeroCamiseta, int cantPartidosDisputados) {
        super(nombre, pais, nivelExperiencia);
        super.validarInt(numeroCamiseta, "El numeroCamiseta no puede ser menor a cero.");
        super.validarInt(cantPartidosDisputados, "El numeroCamiseta no puede ser menor a cero.");
        
        this.numeroCamiseta = numeroCamiseta;
        this.cantPartidosDisputados = cantPartidosDisputados;
    }

    public int getNumeroCamiseta() {
        return numeroCamiseta;
    }

    public int getCantPartidosDisputados() {
        return cantPartidosDisputados;
    }
    

    @Override
    public String entrenar() {
        return "El futbolista "+getNombre()+" de "+getPais()+" realizo el entrenamiento.";
    }

    @Override
    public String toString() {
        return super.toString()+" " + "numeroCamiseta=" + numeroCamiseta + ", cantPartidosDisputados=" + cantPartidosDisputados ;
    }
  
    
}
