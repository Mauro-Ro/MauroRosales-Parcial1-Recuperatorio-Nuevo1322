/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package gestionparticipantesmundial;

import gestionparticipantesmundial.NivelExperiencia;
import gestionparticipantesmundial.NivelExperiencia;

/**
 *
 * @author Mauro Rosales
 */
public class JugadorDeCampo extends Futbolista{
    private int golesConvertidos;

    public JugadorDeCampo(String nombre, String pais, NivelExperiencia nivelExperiencia, int numeroCamiseta, int cantPartidosDisputados, int golesConvertidos) {
        super(nombre, pais, nivelExperiencia, numeroCamiseta, cantPartidosDisputados);
        super.validarInt(golesConvertidos, "Los golesConvertidos no pueden ser menor a cero.");
        this.golesConvertidos = golesConvertidos;
    }

    @Override
    public String toString() {
        return super.toString()+" " + "golesConvertidos=" + golesConvertidos + "]";
    }

    


}
