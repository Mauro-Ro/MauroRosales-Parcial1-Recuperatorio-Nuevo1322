/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package gestionparticipantesmundial;

/**
 *
 * @author Mauro Rosales
 */
public class Arbitro extends Participante implements Informable{
    private int cantidadPartidosDirigidos;

    public Arbitro(String nombre, String pais, NivelExperiencia nivelExperiencia, int cantidadPartidosDirigidos) {
        super(nombre, pais, nivelExperiencia);
        super.validarInt(cantidadPartidosDirigidos, "La cantidadPartidosDirigidos no puede ser menor a cero.");

        this.cantidadPartidosDirigidos = cantidadPartidosDirigidos;
    }

    @Override
    public String toString() {
        return super.toString()+" " + "cantidadPartidosDirigidos=" + cantidadPartidosDirigidos + "]";
    }

    @Override
    public String generarInforme() {
       return "Informe del arbitro "+getNombre()+": "+cantidadPartidosDirigidos+" partidos dirigidos.";
    }
    
 
    
    
}
