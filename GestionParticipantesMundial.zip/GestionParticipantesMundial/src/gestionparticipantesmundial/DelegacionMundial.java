/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package gestionparticipantesmundial;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class DelegacionMundial {
    private String nombre;
    private List<Participante> participantes = new ArrayList<Participante>();


    /**
     * Constructor de la delegación.
     * 
     * @param nombre Nombre de la delegación.
     * @throws NullPointerException si el nombre es null o vacío.
     */
    public DelegacionMundial(String nombre) {
        validarString(nombre,"El nombre no puede ser null o estar vacio.");
        this.nombre = nombre;
    }

    /**
     * Valida que un String no sea null ni vacío.
     * 
     * @param string Cadena a validar.
     * @param message Mensaje de error en caso de invalidación.
     * @throws NullPointerException si la cadena es null o está vacía.
     */
    public void validarString(String string, String message){
        if (string == null || string.isBlank()) {
            throw new NullPointerException(message);
        }
    }

    /**
     * Agrega un participante a la delegación.
     * 
     * @param participante Participante a agregar.
     * @throws NullPointerException si el participante es null.
     * @throws ParticipanteDuplicadoException si el participante ya existe.
     */
    public void agregarParticipante(Participante participante) throws ParticipanteDuplicadoException{
        Objects.requireNonNull(participante, "No se pudo agregar el participante: ");
        validarParticipanteDuplicado(participante);
        participantes.add(participante);
    }
    
    /**
     * Obtiene la lista de participantes de la delegación.
     * Se devuelve una copia para evitar modificaciones externas.
     * 
     * @return Lista de participantes.
     */
    public List<Participante> obtenerParticipantes(){
        return new ArrayList<>(participantes);
    }

    /**
     * Filtra los participantes según su nivel de experiencia.
     * 
     * @param nivelExperiencia Nivel de experiencia a filtrar.
     * @return Lista de participantes que coinciden con el nivel indicado.
     * @throws NullPointerException si el nivelExperiencia es null.
     */
    public List<Participante> filtrarPorExperiencia(NivelExperiencia nivelExperiencia){
        Objects.requireNonNull(nivelExperiencia, "El nivelExperiencia no puede ser null.");
        List<Participante> filtrada = new ArrayList<>();
        
        for (Participante participante : participantes) {
            if (participante.getNivelExperiencia() == nivelExperiencia) {
                filtrada.add(participante);
            }
        }
        return filtrada;
    }
    
    /**
     * Valida que un participante no esté duplicado en la delegación.
     * 
     * @param participante Participante a validar.
     * @throws ParticipanteDuplicadoException si ya existe un participante igual.
     */
    public void validarParticipanteDuplicado(Participante participante) throws ParticipanteDuplicadoException{
        if (participantes.contains(participante)) {
            throw new ParticipanteDuplicadoException(
                "Ya existe un participante llamado '"+participante.getNombre()+
                "' que representa a '"+ participante.getPais() +"'."
            );
        }
    }
}
