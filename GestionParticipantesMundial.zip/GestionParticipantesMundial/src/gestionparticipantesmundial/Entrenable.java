/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package gestionparticipantesmundial;

/**
 *
 * @author Mauro Rosales
 */
interface Entrenable {
    /**
     * Realiza el entrenamiento del participante.
     * @return resultado del entrenamiento.
     */
    String entrenar();
}
