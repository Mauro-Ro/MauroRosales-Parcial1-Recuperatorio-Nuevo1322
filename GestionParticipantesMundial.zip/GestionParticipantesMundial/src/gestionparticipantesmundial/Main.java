/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gestionparticipantesmundial;


import java.util.List;
import java.util.Objects;

public class Main {
    public static void main(String[] args) {

        DelegacionMundial delegacion = new DelegacionMundial("Delegacion Internacional");

        try {
            delegacion.agregarParticipante(
                    new JugadorDeCampo(
                            "Lionel Acosta",
                            "Argentina",
                            NivelExperiencia.VETERANO,
                            10,
                            26,
                            12));

            delegacion.agregarParticipante(
                    new Arquero(
                            "Bruno Silva",
                            "Brasil",
                            NivelExperiencia.EXPERIMENTADO,
                            1,
                            18,
                            35));

            delegacion.agregarParticipante(
                    new Arbitro(
                            "Martin Lopez",
                            "Uruguay",
                            NivelExperiencia.VETERANO,
                            42));

            delegacion.agregarParticipante(
                    new Arquero(
                            "Daniel Meyer",
                            "Alemania",
                            NivelExperiencia.DEBUTANTE,
                            12,
                            5,
                            9));

            delegacion.agregarParticipante(
                    new JugadorDeCampo(
                            "Lionel Acosta",
                            "Argentina",
                            NivelExperiencia.EXPERIMENTADO,
                            18,
                            10,
                            4));

        } catch (ParticipanteDuplicadoException e) {
            System.out.println(
                    "No se pudo agregar el participante: " + e.getMessage());
        }

        System.out.println("Participantes registrados:");
        mostrarParticipantes(delegacion.obtenerParticipantes());

        System.out.println();

        int entrenables =
                entrenarParticipantes(delegacion.obtenerParticipantes());

        System.out.println(
                "Cantidad de participantes entrenables: " + entrenables);

        System.out.println();

        int informes =
                generarInformes(delegacion.obtenerParticipantes());

        System.out.println(
                "Cantidad de informes generados: " + informes);

        System.out.println();

        System.out.println("Participantes VETERANOS:");

        mostrarParticipantes(
                delegacion.filtrarPorExperiencia(
                        NivelExperiencia.VETERANO));
    }

    private static void mostrarParticipantes(
            List<Participante> participantes) {

        if (participantes.isEmpty()) {
            System.out.println("No hay participantes para mostrar.");
            return;
        }

        for (Participante participante : participantes) {
            Objects.requireNonNull(participante);
            System.out.println(participante);
        }
    }

    private static int entrenarParticipantes(
            List<Participante> participantes) {

        int cantidad = 0;

        for (Participante participante : participantes) {
            Objects.requireNonNull(participante);

            if (participante instanceof Entrenable entrenable) {
                System.out.println(entrenable.entrenar());
                cantidad++;
            } else {
                System.out.println(
                        "El participante '"
                                + participante.getNombre()
                                + "' no realiza entrenamiento como futbolista.");
            }
        }

        return cantidad;
    }

    private static int generarInformes(
            List<Participante> participantes) {

        int cantidad = 0;

        for (Participante participante : participantes) {
            Objects.requireNonNull(participante);

            if (participante instanceof Informable informable) {
                System.out.println(informable.generarInforme());
                cantidad++;
            } else {
                System.out.println(
                        "El participante '"
                                + participante.getNombre()
                                + "' no genera informe.");
            }
        }

        return cantidad;
    }
    
}
