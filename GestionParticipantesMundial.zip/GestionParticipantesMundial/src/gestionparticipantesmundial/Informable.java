/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package gestionparticipantesmundial;

/**
 *
 * @author Mauro Rosales
 */
interface Informable {
    /**
     * Genera un informe del participante.
     * @return informe en formato String.
     */
    String generarInforme();
}
