/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package gestionparticipantesmundial;

import java.util.Objects;

/**
 *
 * @author Mauro Rosales
 */
public abstract class Participante {
    private String nombre;
    private String pais;
    private NivelExperiencia nivelExperiencia;

    public Participante(String nombre, String pais, NivelExperiencia nivelExperiencia) {
        validarString(nombre,"El nombre no puede ser null o estar vacio.");
        validarString(pais, "El pais no puede ser null o estar vacio.");
        Objects.requireNonNull(nivelExperiencia, "El nivelExperiencia no puede ser null.");
        this.nombre = nombre;
        this.pais = pais;
        this.nivelExperiencia = nivelExperiencia;
    }

    public void validarInt(int num, String message){
        if (num < 0) {
                throw new IllegalArgumentException(message);
        }
    }
    
    
    public void validarString(String string, String message){
        if (string == null || string.isBlank()) {
                throw new IllegalArgumentException(message);
        }
    }

    public String getNombre() {
        return nombre;
    }

    public String getPais() {
        return pais;
    }

    public NivelExperiencia getNivelExperiencia() {
        return nivelExperiencia;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 19 * hash + Objects.hashCode(this.nombre);
        hash = 19 * hash + Objects.hashCode(this.pais);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        final Participante other = (Participante) obj;
        
        return Objects.equals(this.nombre, other.nombre) && Objects.equals(this.pais, other.pais);
    }

    @Override
    public String toString() {
        return getClass().getSimpleName()+" [" + "nombre=" + nombre + ", pais=" + pais + ", nivelExperiencia=" + nivelExperiencia;
    }
    
    
    
}
