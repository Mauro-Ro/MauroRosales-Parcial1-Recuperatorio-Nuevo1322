/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package gestionparticipantesmundial;

/**
 *
 * @author Mauro Rosales
 */
public class ParticipanteDuplicadoException extends Exception{

    public ParticipanteDuplicadoException() {
    }

    public ParticipanteDuplicadoException(String message) {
        super(message);
    }

    
    
}
